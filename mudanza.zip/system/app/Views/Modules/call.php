	<section id="call-to-action" class="wow fadeInUp">
		<div class="container">
			<div class="row">
				<div class="col-lg-9 text-center text-lg-left">
					<h3 class="cta-title">Nuestro compromiso</h3>
					<p class="cta-text">Nuestro compromiso se basa en la calidad de nuestro servicio, en el cumplimiento de los
						plazos, y en la utilizacion de un personal altamente especializado y capatizado, generando así, la
						satisfacción total de nuestros clientes.</p>
				</div>
				<div class="col-lg-3 cta-btn-container text-center">
					<a class="cta-btn align-middle" href="#">Saber mas</a>
				</div>
			</div>
		</div>
	</section>